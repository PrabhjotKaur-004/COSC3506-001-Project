module com.cds.cds {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.cds.cds to javafx.fxml;
    opens com.cds.cds.controllers to javafx.fxml;
    exports com.cds.cds;
}
