/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.controllers;

import com.cds.cds.models.Campaign;
import com.cds.cds.models.Donation;
import com.cds.cds.services.CampaignService;
import com.cds.cds.services.DonationService;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controls the Donor Dashboard.
 */
public class DonorDashboardController {

    @FXML
    private TableView<Campaign> campaignTable;
    @FXML
    private TableColumn<Campaign, String> colCampaignName;
    @FXML
    private TableColumn<Campaign, Double> colGoalAmount;
    @FXML
    private TableColumn<Campaign, Double> colRaisedAmount;
    @FXML
    private TextField txtDonationAmount;
    @FXML
    private Button btnDonate;
    @FXML
    private TableView<Donation> donationTable;
    @FXML
    private TableColumn<Donation, Double> colDonationAmount;
    @FXML
    private TableColumn<Donation, String> colDonationDate;

    private final CampaignService campaignService = new CampaignService();
    private final DonationService donationService = new DonationService();
    private ObservableList<Campaign> campaignList = FXCollections.observableArrayList();
    private ObservableList<Donation> donationList = FXCollections.observableArrayList();
    private Campaign selectedCampaign;

    @FXML
    public void initialize() throws SQLException {
        setupCampaignTable();
        setupDonationTable();
        loadActiveCampaigns();
        loadDonationHistory();

        campaignTable.setOnMouseClicked(event -> handleTableClick());
    }

    private void setupCampaignTable() {
        colCampaignName.setCellValueFactory(cellData -> cellData.getValue().campaignNameProperty());
        colGoalAmount.setCellValueFactory(cellData -> cellData.getValue().goalAmountProperty().asObject());
        colRaisedAmount.setCellValueFactory(cellData -> cellData.getValue().raisedAmountProperty().asObject());

        campaignTable.setItems(campaignList);
    }

    private void setupDonationTable() {
        colDonationAmount.setCellValueFactory(cellData -> cellData.getValue().amountProperty().asObject());
        colDonationDate.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDate().toString()));


        donationTable.setItems(donationList);
    }

    private void loadActiveCampaigns() throws SQLException {
        campaignList.clear();
        List<Campaign> campaigns = campaignService.getActiveCampaigns();
        campaignList.addAll(campaigns);
    }

    private void loadDonationHistory() throws SQLException {
        donationList.clear();
        List<Donation> donations = donationService.getDonationsByDonor(1); // my placeholder
        donationList.addAll(donations);
    }

    private void handleTableClick() {
        selectedCampaign = campaignTable.getSelectionModel().getSelectedItem();
    }

    @FXML
    private void makeDonation() throws SQLException {
        if (selectedCampaign == null) {
            showAlert("Please select a campaign to donate to.");
            return;
        }

        String donationText = txtDonationAmount.getText().trim();
        if (donationText.isEmpty()) {
            showAlert("Please enter a donation amount.");
            return;
        }

        try {
            double amount = Double.parseDouble(donationText);
            if (amount <= 0) {
                showAlert("Donation amount must be greater than zero.");
                return;
            }

            Donation donation = new Donation(0, amount, 1, selectedCampaign.getCampaignId(), new Timestamp(System.currentTimeMillis()));
            donationService.makeDonation(donation.getAmount(), donation.getDonorId(), donation.getCampaignId());

            loadDonationHistory();
            loadActiveCampaigns(); // Refresh campaign list to reflect raised amount update
            txtDonationAmount.clear();
            showSuccessAlert("Donation Successful", "Thank you for your contribution!");

        } catch (NumberFormatException e) {
            showAlert("Invalid amount. Please enter a valid number.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccessAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    @FXML
    private void logout() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/cds/view/login.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) campaignTable.getScene().getWindow();

            // Set the new scene
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error: Unable to load the login page.");
        }
    }
}