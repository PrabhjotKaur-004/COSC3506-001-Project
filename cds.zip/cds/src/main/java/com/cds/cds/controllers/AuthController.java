/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.controllers;

import com.cds.cds.models.User;
import com.cds.cds.services.UserService;
import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * Controls authentication-related operations like login and registration.
 */
public class AuthController {

    private final UserService userService;

    @FXML
    private TextField txtEmail;
    
    @FXML
    private PasswordField txtPassword;

    @FXML
    private TextField txtName;  // Only used for registration

    @FXML
    private PasswordField txtConfirmPassword;  // Only used for registration

    public AuthController() {
        this.userService = new UserService();
    }

    /**
     * Handles user login.
     */
    @FXML
    private void handleLogin(ActionEvent event) {
        String email = txtEmail.getText();
        String password = txtPassword.getText();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Login Failed", "Please enter email and password.");
            return;
        }

        try {
            User user = userService.authenticateUser(email, password);
            if (user != null) {
                showAlert(Alert.AlertType.INFORMATION, "Login Successful", "Welcome, " + user.getName() + "!");
                redirectUser(user);
            } else {
                showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid email or password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while logging in.");
        }
    }

    /**
     * Handles user registration.
     */
    @FXML
    private void handleRegister(ActionEvent event) {
        String name = txtName.getText();
        String email = txtEmail.getText();
        String password = txtPassword.getText();
        String confirmPassword = txtConfirmPassword.getText();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Registration Failed", "All fields are required.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Registration Failed", "Passwords do not match.");
            return;
        }

        try {
            boolean success = userService.registerUser(name, email, password, "DONOR");
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Registration Successful", "You can now log in.");
                clearRegistrationFields();
            } else {
                showAlert(Alert.AlertType.ERROR, "Registration Failed", "Email already in use.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred during registration.");
        }
    }

    /**
     * Redirects the user to their appropriate dashboard based on role.
     */
    private void redirectUser(User user) {
        String fxmlFile;

        switch (user.getRole()) {
            case "ADMIN":
                fxmlFile = "/com/cds/view/admin_dashboard.fxml";
                break;
            case "FUNDRAISER":
                fxmlFile = "/com/cds/view/fundraiser_dashboard.fxml";
                break;
            case "DONOR":
                fxmlFile = "/com/cds/view/donor_dashboard.fxml";
                break;
            default:
                fxmlFile = null;
                break;
        }

        if (fxmlFile != null) {
            try {
                Stage stage = (Stage) txtEmail.getScene().getWindow();
                AnchorPane root = FXMLLoader.load(getClass().getResource(fxmlFile));
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Navigation Error", "Failed to load dashboard.");
            }
        }
    }


    /**
     * Clears registration fields after successful signup.
     */
    private void clearRegistrationFields() {
        txtName.clear();
        txtEmail.clear();
        txtPassword.clear();
        txtConfirmPassword.clear();
    }

    /**
     * Displays an alert dialog.
     */
    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    /**
     * Redirects the user to the registration view.
     */
    @FXML
    private void redirectToRegister() {
        loadScene("/com/cds/view/register.fxml");
    }
    
    /**
     * Redirects the user to the login view.
     */
    @FXML
    private void redirectToLogin() {
        loadScene("/com/cds/view/login.fxml");
    }
    
        /**
     * Loads a new scene from the specified FXML file.
     *
     * @param fxmlFilePath the path to the FXML file
     */
    private void loadScene(String fxmlFilePath) {
        try {
            // Load the FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFilePath));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) txtEmail.getScene().getWindow();

            // Set the new scene
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Failed to load the requested page.");
        }
    }

}