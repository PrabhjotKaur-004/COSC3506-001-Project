/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.services;

import com.cds.cds.dao.DonationDAO;
import com.cds.cds.models.Donation;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

/**
 * Handles business logic related to donation operations.
 */
public class DonationService {
    private final DonationDAO donationDAO;

    public DonationService() {
        this.donationDAO = new DonationDAO();
    }

    /**
     * Processes a donation.
     */
    public boolean makeDonation(double amount, int donorId, int campaignId) throws SQLException {
        if (amount <= 0) {
            throw new IllegalArgumentException("Donation amount must be greater than zero.");
        }
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Donation donation = new Donation(0, amount, donorId, campaignId, timestamp);

        boolean success = donationDAO.addDonation(donation);
        if (success) {
            donationDAO.updateCampaignFunds(campaignId, amount);
        }
        return success;
    }

    /**
     * Retrieves all donations.
     */
    public List<Donation> getAllDonations() throws SQLException {
        return donationDAO.getAllDonations();
    }

    /**
     * Retrieves donations made by a specific donor.
     */
    public List<Donation> getDonationsByDonor(int donorId) throws SQLException {
        return donationDAO.getDonationsByDonor(donorId);
    }

    /**
     * Retrieves donations for a specific campaign.
     */
    public List<Donation> getDonationsByCampaign(int campaignId) throws SQLException {
        return donationDAO.getDonationsByCampaign(campaignId);
    }
    
    public double getTotalDonationsForFundraiser(int fundraiserId) throws SQLException {
        return donationDAO.getTotalDonationsForFundraiser(fundraiserId);
    }

    
}
