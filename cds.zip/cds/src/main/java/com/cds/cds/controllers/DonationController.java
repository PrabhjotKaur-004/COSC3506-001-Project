/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.controllers;

import com.cds.cds.models.Donation;
import com.cds.cds.services.DonationService;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * Controller for handling donations.
 */
public class DonationController {
    private final DonationService donationService = new DonationService();

    @FXML private TextField txtAmount;
    @FXML private TextField txtCampaignId;
    @FXML private TableView<Donation> tblDonations;
    @FXML private TableColumn<Donation, Double> colAmount;
    @FXML private TableColumn<Donation, Integer> colCampaignId;
    @FXML private TableColumn<Donation, Integer> colDonorId;

    @FXML
    public void initialize() throws SQLException {
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colCampaignId.setCellValueFactory(new PropertyValueFactory<>("campaignId"));
        colDonorId.setCellValueFactory(new PropertyValueFactory<>("donorId"));

        loadDonations();
    }

    /**
     * Loads all donations into the table.
     */
    private void loadDonations() throws SQLException {
        List<Donation> donations = donationService.getAllDonations();
        tblDonations.getItems().setAll(donations);
    }

    /**
     * Handles donation processing.
     */
    @FXML
    private void handleMakeDonation(ActionEvent event) throws SQLException {
        double amount;
        int campaignId;

        try {
            amount = Double.parseDouble(txtAmount.getText());
            campaignId = Integer.parseInt(txtCampaignId.getText());
            int donorId = getCurrentUserId(); // Assuming a method to get logged-in user ID

            boolean success = donationService.makeDonation(amount, donorId, campaignId);
            if (success) {
                showAlert("Success", "Donation made successfully!");
                loadDonations();
                clearFields();
            } else {
                showAlert("Error", "Failed to process donation.");
            }
        } catch (NumberFormatException e) {
            showAlert("Validation Error", "Amount and Campaign ID must be valid numbers.");
        } catch (IllegalArgumentException e) {
            showAlert("Error", e.getMessage());
        }
    }

    /**
     * Clears input fields.
     */
    private void clearFields() {
        txtAmount.clear();
        txtCampaignId.clear();
    }

    /**
     * Displays an alert dialog.
     */
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Mock function for fetching logged-in user ID.
     */
    private int getCurrentUserId() {
        return 2; 
    }
    @FXML
    private void goToDonationForm() {
        loadScene("/com/cds/view/donation_form.fxml");
    }

    @FXML
    private void goToDonationsList() {
        loadScene("/com/cds/view/donations.fxml");
    }

    @FXML
    private void goBack() {
        loadScene("/com/cds/view/user_dashboard.fxml"); 
    }

    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = (Stage) tblDonations.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Unable to load page.");
        }
    }
}