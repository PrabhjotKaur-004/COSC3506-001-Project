/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.services;

import com.cds.cds.dao.UserDAO;
import com.cds.cds.models.User;
import java.sql.SQLException;
import java.util.List;

/**
 * Handles business logic related to user operations.
 */
public class UserService {
    private final UserDAO userDAO;

    public UserService() {
        this.userDAO = new UserDAO();
    }

    /**
     * Registers a new user after validating input data.
     */
    public boolean registerUser(String name, String email, String password, String role) throws SQLException {
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || role.isEmpty()) {
            throw new IllegalArgumentException("All fields are required.");
        }
        if (userDAO.getUserByEmail(email) != null) {
            throw new IllegalArgumentException("Email is already registered.");
        }
        User user = new User(0, name, email, password, role);
        return userDAO.addUser(user);
    }

    /**
     * Authenticates a user by verifying email and password.
     */
    public User authenticateUser(String email, String password) throws SQLException {
        User user = userDAO.getUserByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user; // Successful login
        }
        return null; // Login failed
    }

    /**
     * Retrieves a user by ID.
     */
    public User getUserById(int id) throws SQLException {
        return userDAO.getUserById(id);
    }

    /**
     * Updates user details (name, email, password).
     */
    public boolean updateUser(int id, String name, String email, String password) throws SQLException {
        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            throw new IllegalArgumentException("All fields must be filled.");
        }
        User user = new User(id, name, email, password, null);
        return userDAO.updateUser(user);
    }

    /**
     * Deletes a user from the system.
     */
    public boolean deleteUser(int id) throws SQLException {
        return userDAO.deleteUser(id);
    }

    /**
     * Retrieves all users in the system.
     */
    public List<User> getAllUsers() throws SQLException {
        return userDAO.getAllUsers();
    }

}