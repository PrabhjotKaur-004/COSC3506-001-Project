/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.models;

import java.sql.Timestamp;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Represents a Donation in the system.
 */
public class Donation {
    private final IntegerProperty id;
    private final DoubleProperty amount;
    private final IntegerProperty donorId;
    private final IntegerProperty campaignId;
    private final ObjectProperty<Timestamp> date;

    public Donation(int id, double amount, int donorId, int campaignId, Timestamp date) {
        this.id = new SimpleIntegerProperty(id);
        this.amount = new SimpleDoubleProperty(amount);
        this.donorId = new SimpleIntegerProperty(donorId);
        this.campaignId = new SimpleIntegerProperty(campaignId);
        this.date = new SimpleObjectProperty<>(date);
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public double getAmount() {
        return amount.get();
    }

    public DoubleProperty amountProperty() {
        return amount;
    }

    public int getDonorId() {
        return donorId.get();
    }

    public IntegerProperty donorIdProperty() {
        return donorId;
    }

    public int getCampaignId() {
        return campaignId.get();
    }

    public IntegerProperty campaignIdProperty() {
        return campaignId;
    }

    public Timestamp getDate() {
        return date.get();
    }

    public ObjectProperty<Timestamp> dateProperty() {
        return date;
    }
}