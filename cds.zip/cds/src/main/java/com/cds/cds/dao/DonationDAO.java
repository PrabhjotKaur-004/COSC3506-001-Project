/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.dao;
import com.cds.cds.utils.DatabaseConnection;
import com.cds.cds.models.Donation;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles database operations related to donations.
 */
public class DonationDAO {
    private Connection conn;
    Timestamp timestamp = new Timestamp(System.currentTimeMillis()); 
    Instant instant = timestamp.toInstant(); 
    LocalDateTime localDateTime = instant.atZone(ZoneId.systemDefault()).toLocalDateTime();

    public DonationDAO() {
        conn = DatabaseConnection.getConnection();
    }

    /**
     * Adds a new donation to the database.
     */
    public boolean addDonation(Donation donation) throws SQLException {
        String query = "INSERT INTO Donation (amount, donor_id, campaign_id) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDouble(1, donation.getAmount());
            stmt.setInt(2, donation.getDonorId());
            stmt.setInt(3, donation.getCampaignId());
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Updates the total raised amount for a campaign when a donation is made.
     */
    public boolean updateCampaignFunds(int campaignId, double amount) throws SQLException {
        String query = "UPDATE Campaign SET raised_amount = raised_amount + ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDouble(1, amount);
            stmt.setInt(2, campaignId);
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Retrieves all donations.
     */
    public List<Donation> getAllDonations() throws SQLException {
        List<Donation> donations = new ArrayList<>();
        String query = "SELECT * FROM Donation";
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                donations.add(new Donation(
                    rs.getInt("id"),
                    rs.getDouble("amount"),
                    rs.getInt("donor_id"),
                    rs.getInt("campaign_id"),
                    rs.getTimestamp("date") 
                ));
            }
        }
        return donations;
    }


    /**
     * Retrieves all donations made by a specific donor.
     */
    public List<Donation> getDonationsByDonor(int donorId) throws SQLException {
        List<Donation> donations = new ArrayList<>();
        String query = "SELECT * FROM Donation WHERE donor_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, donorId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                donations.add(new Donation(
                    rs.getInt("id"),
                    rs.getDouble("amount"),
                    rs.getInt("donor_id"),
                    rs.getInt("campaign_id"),
                    rs.getTimestamp("date")
                ));
            }
        }
        return donations;
    }

    /**
     * Retrieves all donations for a specific campaign.
     */
    public List<Donation> getDonationsByCampaign(int campaignId) throws SQLException {
        List<Donation> donations = new ArrayList<>();
        String query = "SELECT * FROM Donation WHERE campaign_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, campaignId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                donations.add(new Donation(
                    rs.getInt("id"),
                    rs.getDouble("amount"),
                    rs.getInt("donor_id"),
                    rs.getInt("campaign_id"),
                    rs.getTimestamp("date")
                ));
            }
        }
        return donations;
    }

    public double getTotalDonationsForFundraiser(int fundraiserId) throws SQLException {
        String query = "SELECT SUM(amount) FROM donations WHERE campaign_id IN (SELECT id FROM campaigns WHERE fundraiser_id = ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, fundraiserId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getDouble(1) : 0.0;
        }
    }

}