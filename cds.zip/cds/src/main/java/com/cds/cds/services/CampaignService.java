/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.services;

import com.cds.cds.dao.CampaignDAO;
import com.cds.cds.models.Campaign;
import java.sql.SQLException;
import java.util.List;

/**
 * Handles business logic related to campaign operations.
 */
public class CampaignService {
    private final CampaignDAO campaignDAO;

    public CampaignService() {
        this.campaignDAO = new CampaignDAO();
    }

    /**
     * Creates a new campaign.
     */
    public boolean createCampaign(String title, String description, double goalAmount, int fundraiserId) throws SQLException {
        if (title.isEmpty() || description.isEmpty() || goalAmount <= 0) {
            throw new IllegalArgumentException("All fields must be valid.");
        }
        Campaign campaign = new Campaign(0, title, description, goalAmount, 0, fundraiserId);
        return campaignDAO.addCampaign(campaign);
    }
    public boolean addCampaign(Campaign campaign) throws SQLException {
        return campaignDAO.addCampaign(campaign);
    }


    /**
     * Retrieves a campaign by its ID.
     */
    public Campaign getCampaignById(int id) throws SQLException {
        return campaignDAO.getCampaignById(id);
    }

    /**
     * Updates campaign details.
     */
    public boolean updateCampaign(int id, String title, String description, double goalAmount) throws SQLException {
        if (title.isEmpty() || description.isEmpty() || goalAmount <= 0) {
            throw new IllegalArgumentException("Invalid campaign details.");
        }
        Campaign campaign = new Campaign(id, title, description, goalAmount, 0, 0);
        return campaignDAO.updateCampaign(campaign);
    }

    /**
     * Deletes a campaign.
     */
    public boolean deleteCampaign(int id) throws SQLException {
        return campaignDAO.deleteCampaign(id);
    }

    /**
     * Retrieves all campaigns.
     */
    public List<Campaign> getAllCampaigns() throws SQLException {
        return campaignDAO.getAllCampaigns();
    }

    /**
     * Retrieves campaigns by fundraiser ID.
     */
    public List<Campaign> getCampaignsByFundraiser(int fundraiserId) throws SQLException {
        return campaignDAO.getCampaignsByFundraiser(fundraiserId);
    }
    
    public List<Campaign> getActiveCampaigns() throws SQLException {
        return campaignDAO.getAllCampaigns();
    }
}