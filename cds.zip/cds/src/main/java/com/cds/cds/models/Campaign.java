/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.models;

/**
 * Represents a Campaign in the system.
 */
import javafx.beans.property.*;

public class Campaign {
    private final IntegerProperty campaignId;
    private final StringProperty campaignName;
    private final StringProperty description;
    private final DoubleProperty goalAmount;
    private final DoubleProperty raisedAmount;
    private final IntegerProperty fundraiserId;

    
    public Campaign(String campaignName, String description, double goalAmount, double raisedAmount, int fundraiserId) {
        this.campaignName = new SimpleStringProperty(campaignName);
        this.description = new SimpleStringProperty(description);
        this.goalAmount = new SimpleDoubleProperty(goalAmount);
        this.raisedAmount = new SimpleDoubleProperty(raisedAmount);
        this.fundraiserId = new SimpleIntegerProperty(fundraiserId);
        this.campaignId = null;
    }

    public Campaign(int campaignId, String campaignName, String description, double goalAmount, double raisedAmount, int fundraiserId) {
        this.campaignId = new SimpleIntegerProperty(campaignId);
        this.campaignName = new SimpleStringProperty(campaignName);
        this.description = new SimpleStringProperty(description);
        this.goalAmount = new SimpleDoubleProperty(goalAmount);
        this.raisedAmount = new SimpleDoubleProperty(raisedAmount);
        this.fundraiserId = new SimpleIntegerProperty(fundraiserId);
    }
    
    public StringProperty campaignNameProperty() { return campaignName; }
    public StringProperty descriptionProperty() { return description; }
    public DoubleProperty goalAmountProperty() { return goalAmount; }
    public DoubleProperty raisedAmountProperty() { return raisedAmount; }

    public int getCampaignId() { return campaignId.get(); }
    public String getCampaignName() { return campaignName.get(); }
    public String getDescription() { return description.get(); }
    public double getGoalAmount() { return goalAmount.get(); }
    public double getRaisedAmount() { return raisedAmount.get(); }
    public int getFundraiserId(){return fundraiserId.get();}
    
    public void setCampaignName(String name) { campaignName.set(name); }
    public void setDescription(String desc) { description.set(desc); }
    public void setGoalAmount(double goal) { goalAmount.set(goal); }
    public void setRaisedAmount(double raised) { raisedAmount.set(raised); }
  
}
