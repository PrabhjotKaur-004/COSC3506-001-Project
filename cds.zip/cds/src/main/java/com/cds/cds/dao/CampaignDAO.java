/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.dao;
import com.cds.cds.utils.DatabaseConnection;
import com.cds.cds.models.Campaign;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles Campaign-related database operations.
 */
public class CampaignDAO {
    private Connection conn;

    public CampaignDAO() {
        conn = DatabaseConnection.getConnection();
    }

    // Create a new campaign
    public boolean addCampaign(Campaign campaign) throws SQLException {
        String query = "INSERT INTO Campaign (title, description, goal_amount, raised_amount, fundraiser_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, campaign.getCampaignName());
            stmt.setString(2, campaign.getDescription());
            stmt.setDouble(3, campaign.getGoalAmount());
            stmt.setDouble(4, campaign.getRaisedAmount());
            stmt.setInt(5, campaign.getFundraiserId());
            return stmt.executeUpdate() > 0;
        }
    }

    // Get a campaign by ID
    public Campaign getCampaignById(int id) throws SQLException {
        String query = "SELECT * FROM Campaign WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Campaign(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("description"),
                    rs.getDouble("goal_amount"),
                    rs.getDouble("raised_amount"),
                    rs.getInt("fundraiser_id")
                );
            }
        }
        return null;
    }

    // Update a campaign
    public boolean updateCampaign(Campaign campaign) throws SQLException {
        String query = "UPDATE Campaign SET title = ?, description = ?, goal_amount = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, campaign.getCampaignName());
            stmt.setString(2, campaign.getDescription());
            stmt.setDouble(3, campaign.getGoalAmount());
            stmt.setInt(4, campaign.getCampaignId());
            return stmt.executeUpdate() > 0;
        }
    }

    // Delete a campaign
    public boolean deleteCampaign(int id) throws SQLException {
        String query = "DELETE FROM Campaign WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    // Get all campaigns
    public List<Campaign> getAllCampaigns() throws SQLException {
        List<Campaign> campaigns = new ArrayList<>();
        String query = "SELECT * FROM Campaign";
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                campaigns.add(new Campaign(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("description"),
                    rs.getDouble("goal_amount"),
                    rs.getDouble("raised_amount"),
                    rs.getInt("fundraiser_id")
                ));
            }
        }
        return campaigns;
    }

    // Get campaigns by fundraiser ID
    public List<Campaign> getCampaignsByFundraiser(int fundraiserId) throws SQLException {
        List<Campaign> campaigns = new ArrayList<>();
        String query = "SELECT * FROM Campaign WHERE fundraiser_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, fundraiserId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                campaigns.add(new Campaign(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("description"),
                    rs.getDouble("goal_amount"),
                    rs.getDouble("raised_amount"),
                    rs.getInt("fundraiser_id")
                ));
            }
        }
        return campaigns;
    }
}