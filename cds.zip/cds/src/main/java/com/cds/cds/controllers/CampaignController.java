/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.controllers;

import com.cds.cds.models.Campaign;
import com.cds.cds.services.CampaignService;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * Controller for managing campaigns.
 */
public class CampaignController {
    private final CampaignService campaignService = new CampaignService();

    @FXML private TextField txtTitle;
    @FXML private TextArea txtDescription;
    @FXML private TextField txtGoalAmount;
    @FXML private TableView<Campaign> tblCampaigns;
    @FXML private TableColumn<Campaign, String> colTitle;
    @FXML private TableColumn<Campaign, String> colDescription;
    @FXML private TableColumn<Campaign, Double> colGoalAmount;
    @FXML private TableColumn<Campaign, Double> colRaisedAmount;

    @FXML
    public void initialize() {
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colGoalAmount.setCellValueFactory(new PropertyValueFactory<>("goalAmount"));
        colRaisedAmount.setCellValueFactory(new PropertyValueFactory<>("raisedAmount"));

        loadCampaigns();
    }

    /**
     * Loads all campaigns into the table.
     */
    private void loadCampaigns() {
        try {
            List<Campaign> campaigns = campaignService.getAllCampaigns();
            tblCampaigns.getItems().setAll(campaigns);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load campaigns.");
            e.printStackTrace();
        }
    }

    /**
     * Handles the creation of a new campaign.
     */
    @FXML
    private void handleCreateCampaign(ActionEvent event) {
        String title = txtTitle.getText();
        String description = txtDescription.getText();
        double goalAmount;

        try {
            goalAmount = Double.parseDouble(txtGoalAmount.getText());
            int fundraiserId = getCurrentUserId(); // Assuming a method to get logged-in user ID

            boolean success = campaignService.createCampaign(title, description, goalAmount, fundraiserId);
            if (success) {
                showAlert("Success", "Campaign created successfully!");
                loadCampaigns();
                clearFields();
            } else {
                showAlert("Error", "Failed to create campaign.");
            }
        } catch (NumberFormatException e) {
            showAlert("Validation Error", "Goal amount must be a valid number.");
        } catch (SQLException | IllegalArgumentException e) {
            showAlert("Error", e.getMessage());
        }
    }

    /**
     * Handles campaign deletion.
     */
    @FXML
    private void handleDeleteCampaign(ActionEvent event) {
        Campaign selected = tblCampaigns.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Selection Error", "Please select a campaign to delete.");
            return;
        }

        try {
            boolean success = campaignService.deleteCampaign(selected.getCampaignId());
            if (success) {
                showAlert("Success", "Campaign deleted successfully!");
                loadCampaigns();
            } else {
                showAlert("Error", "Failed to delete campaign.");
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Error while deleting campaign.");
            e.printStackTrace();
        }
    }

    /**
     * Clears input fields.
     */
    private void clearFields() {
        txtTitle.clear();
        txtDescription.clear();
        txtGoalAmount.clear();
    }

    /**
     * Displays an alert dialog.
     */
    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Mock function for fetching logged-in user ID.
     */
    private int getCurrentUserId() {
        return 1; // my placeholder
    }
    
    @FXML
    private void goToCreateCampaign() {
        loadScene("/com/cds/view/campaign_form.fxml");
    }

    @FXML
    private void goToCampaignList() {
        loadScene("/com/cds/view/campaigns.fxml");
    }

    @FXML
    private void goBack() {
        loadScene("/com/cds/view/admin_dashboard.fxml"); 
    }

    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = (Stage) tblCampaigns.getScene().getWindow(); // Reference an existing UI element
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Unable to load page.");
        }
    }
}