/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.cds.cds.controllers;

import com.cds.cds.models.Campaign;
import com.cds.cds.models.Donation;
import com.cds.cds.models.User;
import com.cds.cds.services.CampaignService;
import com.cds.cds.services.DonationService;
import com.cds.cds.services.UserService;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controls the Admin Dashboard.
 */
public class AdminDashboardController {

    @FXML
    private Label lblAdminWelcome;

    @FXML
    private TextField txtCampaignId, txtCampaignTitle, txtCampaignDescription, txtCampaignGoal, txtFundraiserId;
    @FXML
    private TextField txtUserId, txtUserName, txtUserEmail, txtUserPassword, txtUserRole;
    @FXML
    private TextField txtDonationId, txtDonationAmount, txtDonorId, txtDonationCampaignId;

    private final CampaignService campaignService;
    private final DonationService donationService;
    private final UserService userService;

    public AdminDashboardController() {
        this.campaignService = new CampaignService();
        this.donationService = new DonationService();
        this.userService = new UserService();
    }

    public void initialize() {
        lblAdminWelcome.setText("Welcome, Admin!");
    }

    // CRUD operations for Campaigns

    @FXML
    private void createCampaign() {
        try {
            String title = txtCampaignTitle.getText();
            String description = txtCampaignDescription.getText();
            double goalAmount = Double.parseDouble(txtCampaignGoal.getText());
            int fundraiserId = Integer.parseInt(txtFundraiserId.getText());

            boolean success = campaignService.createCampaign(title, description, goalAmount, fundraiserId);
            showAlert(success ? "Campaign created successfully!" : "Failed to create campaign.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    @FXML
    private void updateCampaign() {
        try {
            int id = Integer.parseInt(txtCampaignId.getText());
            String title = txtCampaignTitle.getText();
            String description = txtCampaignDescription.getText();
            double goalAmount = Double.parseDouble(txtCampaignGoal.getText());

            boolean success = campaignService.updateCampaign(id, title, description, goalAmount);
            showAlert(success ? "Campaign updated successfully!" : "Failed to update campaign.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    @FXML
    private void deleteCampaign() {
        try {
            int id = Integer.parseInt(txtCampaignId.getText());
            boolean success = campaignService.deleteCampaign(id);
            showAlert(success ? "Campaign deleted successfully!" : "Failed to delete campaign.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    @FXML
    private void getAllCampaigns() throws SQLException {
        List<Campaign> campaigns = campaignService.getAllCampaigns();
        campaigns.forEach(System.out::println);
    }

    // CRUD operations for Users

    @FXML
    private void registerUser() {
        try {
            String name = txtUserName.getText();
            String email = txtUserEmail.getText();
            String password = txtUserPassword.getText();
            String role = txtUserRole.getText();

            boolean success = userService.registerUser(name, email, password, role);
            showAlert(success ? "User registered successfully!" : "Failed to register user.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    @FXML
    private void updateUser() {
        try {
            int id = Integer.parseInt(txtUserId.getText());
            String name = txtUserName.getText();
            String email = txtUserEmail.getText();
            String password = txtUserPassword.getText();

            boolean success = userService.updateUser(id, name, email, password);
            showAlert(success ? "User updated successfully!" : "Failed to update user.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    @FXML
    private void deleteUser() {
        try {
            int id = Integer.parseInt(txtUserId.getText());
            boolean success = userService.deleteUser(id);
            showAlert(success ? "User deleted successfully!" : "Failed to delete user.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    @FXML
    private void getAllUsers() throws SQLException {
        List<User> users = userService.getAllUsers();
        users.forEach(System.out::println);
    }

    // CRUD operations for Donations

    @FXML
    private void processDonation() {
        try {
            double amount = Double.parseDouble(txtDonationAmount.getText());
            int donorId = Integer.parseInt(txtDonorId.getText());
            int campaignId = Integer.parseInt(txtDonationCampaignId.getText());

            boolean success = donationService.makeDonation(amount, donorId, campaignId);
            showAlert(success ? "Donation processed successfully!" : "Failed to process donation.");
        } catch (Exception e) {
            showAlert("Error: " + e.getMessage());
        }
    }

    @FXML
    private void getAllDonations() throws SQLException {
        List<Donation> donations = donationService.getAllDonations();
        donations.forEach(System.out::println);
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(message);
        alert.show();
    }
    
    @FXML
    private void logout() {
        try {
            // Load the login view
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/cds/view/login.fxml"));
            Parent root = loader.load();

            // Get the current stage
            Stage stage = (Stage) lblAdminWelcome.getScene().getWindow();

            // Set the new scene
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error: Unable to load the login page.");
        }
    }
}