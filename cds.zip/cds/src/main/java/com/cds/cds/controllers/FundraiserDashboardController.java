
package com.cds.cds.controllers;

import com.cds.cds.models.Campaign;
import com.cds.cds.services.CampaignService;
import com.cds.cds.services.DonationService;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * Controls the Fundraiser Dashboard.
 */
public class FundraiserDashboardController {

    @FXML
    private TableView<Campaign> campaignsTable;
    @FXML
    private TableColumn<Campaign, String> colCampaignName;
    @FXML
    private TableColumn<Campaign, String> colDescription;
    @FXML
    private TableColumn<Campaign, Double> colGoalAmount;
    @FXML
    private TableColumn<Campaign, Double> colRaisedAmount;
    @FXML
    private TextField txtCampaignName;
    @FXML
    private TextArea txtDescription;
    @FXML
    private TextField txtGoalAmount;
    @FXML
    private Button btnCreateCampaign;
    @FXML
    private Button btnUpdateCampaign;
    @FXML
    private Button btnDeleteCampaign;
    @FXML
    private Label lblDonationsReceived;

    private final CampaignService campaignService = new CampaignService();
    private final DonationService donationService = new DonationService();
    private final ObservableList<Campaign> campaignList = FXCollections.observableArrayList();
    private Campaign selectedCampaign;

    // TODO: Replace with the actual logged-in fundraiser's ID
    private final int fundraiserId = 1;  

    @FXML
    public void initialize() {
        setupCampaignTable();
        try {
            loadFundraiserCampaigns();
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load campaigns: " + e.getMessage());
        }
    }

    private void setupCampaignTable() {
        colCampaignName.setCellValueFactory(cellData -> cellData.getValue().campaignNameProperty());
        colDescription.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
        colGoalAmount.setCellValueFactory(cellData -> cellData.getValue().goalAmountProperty().asObject());
        colRaisedAmount.setCellValueFactory(cellData -> cellData.getValue().raisedAmountProperty().asObject());

        campaignsTable.setItems(campaignList);
        campaignsTable.setOnMouseClicked(this::handleTableClick);
    }

    private void loadFundraiserCampaigns() throws SQLException {
        campaignList.clear();
        List<Campaign> campaigns = campaignService.getCampaignsByFundraiser(fundraiserId);
        campaignList.addAll(campaigns);
        updateDonationsReceived();
    }

    private void updateDonationsReceived() {
        try {
            double totalDonations = donationService.getTotalDonationsForFundraiser(fundraiserId);
            lblDonationsReceived.setText("Total Donations Received: $" + totalDonations);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load donations: " + e.getMessage());
        }
    }

    @FXML
    private void createCampaign(ActionEvent event) {
        String name = txtCampaignName.getText().trim();
        String description = txtDescription.getText().trim();

        if (name.isEmpty() || description.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please fill all fields.");
            return;
        }

        try {
            double goalAmount = Double.parseDouble(txtGoalAmount.getText().trim());
            if (goalAmount <= 0) {
                throw new NumberFormatException();
            }

            boolean success = campaignService.createCampaign(name, description, goalAmount, fundraiserId);
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Campaign created successfully.");
                loadFundraiserCampaigns();
                clearForm();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to create campaign.");
            }

        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please enter a valid goal amount.");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to create campaign: " + e.getMessage());
        }
    }

    @FXML
    private void updateCampaign(ActionEvent event) {
        if (selectedCampaign == null) {
            showAlert(Alert.AlertType.WARNING, "Selection Error", "Please select a campaign to update.");
            return;
        }

        String name = txtCampaignName.getText().trim();
        String description = txtDescription.getText().trim();

        if (name.isEmpty() || description.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please fill all fields.");
            return;
        }

        try {
            double goalAmount = Double.parseDouble(txtGoalAmount.getText().trim());
            if (goalAmount <= 0) {
                throw new NumberFormatException();
            }

            boolean success = campaignService.updateCampaign(
                    selectedCampaign.getCampaignId(),
                    name,
                    description,
                    goalAmount
            );

            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Campaign updated successfully.");
                loadFundraiserCampaigns();
                clearForm();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to update campaign.");
            }

        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please enter a valid goal amount.");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to update campaign: " + e.getMessage());
        }
    }

    @FXML
    private void deleteCampaign(ActionEvent event) {
        if (selectedCampaign == null) {
            showAlert(Alert.AlertType.WARNING, "Selection Error", "Please select a campaign to delete.");
            return;
        }

        try {
            boolean success = campaignService.deleteCampaign(selectedCampaign.getCampaignId());
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Campaign deleted successfully.");
                loadFundraiserCampaigns();
                clearForm();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete campaign.");
            }

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to delete campaign: " + e.getMessage());
        }
    }

    private void handleTableClick(MouseEvent event) {
        selectedCampaign = campaignsTable.getSelectionModel().getSelectedItem();
        if (selectedCampaign != null) {
            txtCampaignName.setText(selectedCampaign.getCampaignName());
            txtDescription.setText(selectedCampaign.getDescription());
            txtGoalAmount.setText(String.valueOf(selectedCampaign.getGoalAmount()));
        }
    }

    private void clearForm() {
        txtCampaignName.clear();
        txtDescription.clear();
        txtGoalAmount.clear();
        selectedCampaign = null;
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private void goBack() {
        loadScene("/com/cds/view/main.fxml");
    }

    private void loadScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = (Stage) campaignsTable.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Navigation Error", "Unable to load page.");
        }
    }
}