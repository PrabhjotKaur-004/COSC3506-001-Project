package com.cds.cds;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Main entry point for the application.
 */
public class App extends Application {

    @Override
    public void start(Stage stage) throws Exception {
       
        

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/cds/cds/views/main.fxml"));
        Scene scene = new Scene(loader.load());
        
        stage.setTitle("Welcome to Fundraiser System");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}